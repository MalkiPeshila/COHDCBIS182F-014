<html>
<head>
<title>Login</title>
</head>
<body>
<h1>Login</h1>
    <form method="post" action="#">
    	<input type="text" name="txt_user" placeholder="Username" required /></br>
        <input type="password" name="txt_pwd" placeholder="Password" required />
        </br>
        <hr />
        <button type="submit">Login</button>
    </form> 
</body>
</html>
<?php
session_start();
if(isset($_POST["txt_pwd"]))
{
	$hash_user='$2y$10$e5cLnel.IObnSdJN/1vmQOciXbtvHEg.AY/jwZW0inHE37qyJSbpi';
	$hash_password = '$2y$10$cQZAtxbw8fZw0AQlY/eMQOJ3MG4jaF1Sot.zKyPIztgYki/CqbQzC';


	if (password_verify($_POST["txt_pwd"], $hash_password)&& password_verify($_POST["txt_user"],$hash_user)) {
    	echo 'Password is valid!';
		$_SESSION['Last_Time']=time();
		header("Location:Home.php");
		exit();
	} else {
		echo '<script language="javascript">';
		echo' alert("Invalid UserName Or Password")';
		echo '</script>';
	
	}
}




?>